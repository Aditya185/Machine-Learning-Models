package pjava.ch04.bankaccount_v2;

public class InsuffBalanceException extends Throwable{
    
}
