package pjava.ch04.inventory.iterable0;

import pjava.ch04.inventory.*;
import java.util.ArrayList;

public class Inventory{ 
    public Inventory(){ 
            //initialized with null set of inventory items

        items = new ArrayList<>();

    } 
    public void addNewInventoryItem(InventoryItem new_item){ 

        items.add( new_item );

    } 
    public void addStock(int item_code, int qty) throws ItemNotFound { 
            //adds specified qty of specified item to the inventory
            //you may have locate the specified item in the collection before increasing its stock

        InventoryItem itm = search( item_code );
        itm.addStock(qty);

    } 
    public void withdrawStock(int item_code, int qty) 
                             throws ItemNotFound, InSufficientStock { 

        InventoryItem itm = search( item_code );
        itm.withdrawStock(qty);

    } 
    public InventoryItem[] itemsUnderStock() {

        ArrayList<InventoryItem> items_us = new ArrayList<InventoryItem>();

        for( InventoryItem itm : items) {

            if ( itm.isUnderStock() ) {
                //you can not directly add this item to items_us
                //rather return clone of.
                InventoryItem x = new InventoryItem( 
                        itm.getItemCode(),
                        itm.getItemDescription(), 
                        itm.getStock(),
                        itm.getMinRequiredStock(),
                        itm.getCost() );
                //if clone method had been defined with InventoryItem,
                //you could have used that instead of explicitly copied,
                //as x = itm.clone();
                items_us.add( x );
            }
        }
        //below is typical way of converting arraylist object to array object.
        InventoryItem[] t = new InventoryItem[0];
        t= items_us.toArray(t);
        return t;
    }
    private InventoryItem search(int item_code) throws ItemNotFound {
            //returns item object with given item code, if found

        for( InventoryItem itm : items) {
            if ( itm.getItemCode() == item_code )
                return itm;
        }

        throw new ItemNotFound();

    }

    public double totalInventoryCost() {

        double cost = 0;

        for( InventoryItem itm : items) {

            cost += itm.getCost() * itm.getStock();
            
        }
        
        return cost;

    }
    
    public void moveFirst() {
        current_pos = 0;
    }

    public boolean hasMoreItems() {
        return !(current_pos == items.size());
    }
    
    public InventoryItem next() {
        return items.get(current_pos++).clone();
    }
    
    //Field Declarations
    @Override
    public String toString() {
        return "Inventory{" + "items=" + items + ", current_pos=" + current_pos + '}';
    }

    private ArrayList<InventoryItem> items;
    private int current_pos = 0;
    //public HashMap<Integer, InventoryItem> items;

}

