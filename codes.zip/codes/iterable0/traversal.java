private static void preorder(Node n, Visitor v)
{
 if (n == null) { return; }
 v.visit(n.data);
 for (Node c : n.children) { preorder(c, v); }
}
public void preorder(Visitor v) { preorder(root, v); }
public static void main(String[] args)
{
 BinarySearchTree bst = . . .;
 class ShortNameCounter implements Visitor
 {
 public int counter = 0;
 public void visit(Object data)
 {
 if (data.toString().length() <= 5) { counter++; }
 }
 }

 ShortNameCounter v = new ShortNameCounter();
 bst.inorder(v);
 System.out.println("Short names: " + v.counter);
}