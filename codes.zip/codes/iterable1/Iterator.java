package pjava.ch04.inventory.iterable1;

public interface Iterator {
    public boolean hasNext();
    public Object next();
}


