import java.util.Scanner ;
import java.util.Random;
class PollSimulator
{
	public static void main(String[] args)
	{

		Scanner in = new Scanner(System.in);
		String[] candNames = new String[5];
		candNames[0] = "Deep Goyal";
		candNames[1] = "Sneha Mohan";
		candNames[2] = "Praveen Shah";
		candNames[3] = "Akshay Singh";
		candNames[4] = "Somin Majumdar";

		Poll poll = new Poll( candNames );
		int nc = poll.getNumberOfCandidates();
		System.out.println("Enter the index of the candidate for choosing that candidate");
		for (int i = 0 ; i<candNames.length ; i++)
		{
			System.out.println(i+1 + ". " + candNames[i]) ;
		}
		while(in.hasNextInt())
		{
			int x = in.nextInt();
			if(x>0 && x<=candNames.length)
			{
				poll.voteTo( x );
			}
			else
			{
				System.out.println("Please enter an appropriate candidate Index");
			}
			System.out.println("if you want to quit press any key");

		}
		String sr =in.next();								//for flushing the buffer as buffer has taken a String value when exited
		//Assume that candidates are identified as 1 through 5
		//Report the election result
		for(int i = 1; i <= poll.getNumberOfCandidates(); i++ )
		{
			System.out.println(poll.getCandidateName(i) + ": " + poll.votesCount(i));
		}

		private int flag = 0 ;								//flag to denote that the given username and password matches or not
		private String user_name = "Aditya" ;						//encapsulated as a private variable, username
		private String passwd = "Prakash" ;						//encapsulated as a private variable, password
		System.out.println("Enter the User Name ,Password to get result");
		private int trial = 3 ;								//no. of trials
		for(int i =0 ; i<3 ; i++)
		{
			flag = 0 ;
			System.out.print("Username : ");
			String u_n = in.next();
			if(!u_n.equals("Aditya"))						//matching the input and username
			{
				flag = -1 ;
			}
			System.out.print("Password : ");					//matching the password
			String pass = in.next();
			if(!pass.equals("Prakash"))
			{
				flag = -1 ;
			}
			if(flag==-1)								//flag==-1 signifies that given input is incorrect
			{
				System.out.println("Either User Name or Password is incorrect");
				System.out.println(i!=2?((2-i) + " attempts left ,try one more time"):"");
			}
			else
				break ;

		}
		if(flag==0)
			System.out.println("Winner: " + poll.getWinner());                      //winner name
		else
			System.out.print("You have lost your chance to view the result go to help menu for other options");
	}
}
